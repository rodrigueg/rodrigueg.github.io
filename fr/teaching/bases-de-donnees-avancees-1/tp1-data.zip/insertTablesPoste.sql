--
-- Base de données: `Poste`
--

--
-- Contenu de la table `Depot`
--

INSERT INTO `Depot` (`n_dep`, `nom_dep`, `adr`) VALUES
(310, 'CAFE DE LA GARE', 'BURES'),
(311, 'CAFE DE PARIS', 'ARCUEIL'),
(324, 'PRESSE_CITY', 'PARIS'),
(325, 'CAFE DU COMMERCE', 'ORSAY'),
(328, 'LE MOZARD', 'PARIS'),
(345, 'CAFE LE FONTENAY', 'BURES'),
(357, 'CAFE DE LA GARE', 'PARIS'),
(365, 'CAFE DES AMIS', 'PARIS'),
(378, 'TABAC DU CENTRE', 'LIMOURS'),
(379, 'LES BRASSEURS', 'PARIS'),
(381, 'L''AVENTURE ', 'BREUILLET');

--
-- Contenu de la table `Journal`
--

INSERT INTO `Journal` (`code_j`, `titre`, `prix`, `type_j`, `periode`, `adr_j`) VALUES
(110, 'LE MONDE', 4, 'INFO', 'quotidien', 'PARIS'),
(115, 'LIBERATION', 4, 'INFO', 'quotidien', 'PARIS'),
(120, 'LA RECHERCHE', 32, 'SCIENCE', 'mensuel', 'PARIS'),
(142, 'TELERAMA', 15, 'TELE', 'hebdo', 'MONTROUGE'),
(145, 'TELE 7 JOURS', 15, 'TELE', 'hebdo', 'PARIS'),
(147, 'LE FIGARO', 5, 'INFO', 'quotidien', 'PARIS'),
(149, 'L EXPRESS', 20, 'INFO', 'hebdo', 'PARIS'),
(153, 'LE CANARD', 20, '', 'hebdo', 'MONTROUGE'),
(156, 'SCIENCE ET VIE', 20, 'SCIENCE', 'mensuel', 'PARIS'),
(160, 'ELLE', 15, 'FEMININ', 'hebdo', 'MONTROUGE'),
(165, 'LE POINT', 20, 'INFO', 'hebdo', 'PARIS'),
(184, 'LE NOUVEL OBS', 20, 'INFO', 'hebdo', 'PARIS'),
(194, 'MARIE CLAIRE', 15, 'FEMININ', 'mensuel', 'MONTROUGE');

--
-- Contenu de la table `Livraison`
--

INSERT INTO `Livraison` (`n_dep`, `code_j`, `date_l`, `qte_l`, `qte_r`) VALUES
(310, 142, '2010-04-30', 50, 5),
(310, 165, '2010-04-30', 24, 3),
(310, 165, '2010-04-09', 50, 5),
(324, 194, '2010-02-23', 10, 2),
(328, 110, '2010-05-04', 20, 0),
(328, 110, '2010-04-09', 30, 1),
(328, 110, '2010-04-11', 30, 3),
(328, 115, '2010-05-05', 10, 1),
(328, 194, '2010-01-25', 12, 1),
(345, 110, '2010-05-04', 48, 1),
(345, 115, '2010-05-03', 40, 2),
(345, 165, '2010-05-04', 10, 2),
(357, 194, '2010-06-16', 18, 3),
(365, 194, '2010-06-23', 25, 0),
(379, 110, '2010-08-18', 40, 0),
(379, 115, '2010-07-02', 44, 0),
(379, 165, '2010-04-25', 100, 4),
(379, 165, '2010-06-30', 80, 0),
(379, 194, '2010-07-01', 15, 4),
(381, 110, '2010-08-07', 20, 0),
(381, 115, '2010-03-08', 20, 0),
(381, 120, '2010-06-19', 25, 0),
(381, 142, '2010-08-04', 50, 4),
(381, 145, '2010-02-22', 10, 0),
(381, 147, '2010-01-10', 20, 0),
(381, 149, '2010-03-10', 40, 4),
(381, 153, '2010-05-31', 20, 0),
(381, 156, '2010-07-26', 25, 0),
(381, 160, '2010-04-17', 24, 0),
(381, 165, '2010-05-16', 20, 0),
(381, 184, '0000-00-00', 30, 1),
(381, 194, '0000-00-00', 10, 0);
