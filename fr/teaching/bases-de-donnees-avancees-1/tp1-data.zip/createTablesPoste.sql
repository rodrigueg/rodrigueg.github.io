--
-- Base de données: `Poste`
--

-- --------------------------------------------------------

--
-- Structure de la table `Depot`
--

CREATE TABLE `Depot` (
  `n_dep` int(11) ,
  `nom_dep` text ,
  `adr` text ,
  PRIMARY KEY  (`n_dep`)
)  ;

-- --------------------------------------------------------

--
-- Structure de la table `Journal`
--

CREATE TABLE `Journal` (
  `code_j` int(11) ,
  `titre` text ,
  `prix` float ,
  `type_j` text ,
  `periode` set('quotidien','mensuel','hebdo') ,
  `adr_j` text ,
  PRIMARY KEY  (`code_j`)
)  ;

-- --------------------------------------------------------

--
-- Structure de la table `Livraison`
--

CREATE TABLE `Livraison` (
  `n_dep` int(11) ,
  `code_j` int(11) ,
  `date_l` date ,
  `qte_l` int(11) ,
  `qte_r` int(11) 
)  ;


COMMIT;
