-- Drop TABLE participants;
-- Drop TABLE participer;
-- Drop TABLE themes;
-- Drop TABLE entreprises;
-- Drop TABLE animateurs;
-- Drop TABLE animer;
-- Drop TABLE cours;
-- Drop TABLE categories;

CREATE TABLE participants (matricule varchar(6), nom varchar(15), prenom varchar(15), localite varchar(20), code_entreprise varchar(5));
CREATE TABLE participer (code_cours varchar(5), matricule varchar(6));
CREATE TABLE themes (code_theme varchar(5), designation varchar(30), code_categorie varchar(1));
CREATE TABLE entreprises (code_entreprise varchar(5), nom varchar(20), adresse varchar(20));
CREATE TABLE animateurs(matricule_animateur varchar(6),  nom varchar(15), prenom varchar(15));
CREATE TABLE animer (code_cours varchar(5), matricule_animateur varchar(6), nbr_heures int);
CREATE TABLE cours( code_cours varchar(5), niveau varchar(1), datecours date, tarif_hr integer,  prime_resp integer, droit_inscrip integer, code_theme varchar(5));
CREATE TABLE categories(code_categorie varchar(1), libelle varchar(25));
